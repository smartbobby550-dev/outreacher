# Outreacher

Upload a CSV of your clients, write one message with merge fields, preview it, and send personalised emails.

## Setup

1. Install Node.js 18 or newer.
2. In this folder run: `npm install`
3. Copy `.env.example` to `.env` and fill in your email details.
4. Run: `npm start`
5. Open http://localhost:3000

## Email settings (.env)

**Gmail:** turn on 2-Step Verification, then create an App Password at myaccount.google.com/apppasswords. Use it as `SMTP_PASS` (not your normal password). Host `smtp.gmail.com`, port `587`.

**Better for larger lists:** use a sending service such as Resend, SendGrid, Brevo or Mailgun. They give you SMTP details to paste into `.env`. Personal Gmail limits you to roughly 500 emails per day and bulk sending can get flagged.

## CSV format

First row is the header. You need one column with email addresses. Any other column can be used in your message, for example:

```
name,email,company
Ada,ada@example.com,Acme
```

Write `Hi {{name}}` in the subject or message and it is replaced for each person.

## Notes

- Invalid and duplicate addresses are skipped.
- A delay between emails (default 3 seconds) helps with deliverability.
- Download the send log as CSV when finished.
- Only email people who expect to hear from you, and include a way for them to opt out.
